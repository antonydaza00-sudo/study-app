
//-------------------------------

class Leaf
{
  PImage img;
  int x; 
  int y;
  int health;
  int fade;
  int leafID;
  boolean dying;
  boolean dead;
  
  Leaf(int leafID)
  {
   fade=255;
   health=1000;
   this.leafID =  leafID;
   if(leafID%2==0){
   x=55;
   img =loadImage("data/leaf.png");
   }
   else
   {
   img = loadImage("data/leaf1.png");
   x=-55;
   }
  }
  
  void display()
  {
   if(leafID==branch.size()-1)
   {
    if(!onWindow&&studyTime){health-=1;}
    if(dying){fade--;}
    //health = int(map(mouseX,0,width,0,255));
    tint(health*2,health,0,fade);
    if(fade<2){dead=true;}
   }
    else {tint(200);}
   image(img,200+x,height-((leafID*100)+200),100,100);
   strokeWeight(8);
   stroke(0,200,0);
   line(250,height-((leafID*100)+200),250,height-(((leafID-1)*100)+200));
  }
  
}

//____________________________________________________________________________
class customTime
{
 JSONObject entry;
 int timeID;
 button cSave;
 textbox tStart;
 textbox tEnd;
 String start; 
 String error;
 String end;
 String day;
 
 customTime(String day, int timeID)
 {
  this.day = day;
  this.timeID = timeID;
  entry = new JSONObject();
  error = "Input format invalid,\n type time in 24 hour \nformat without colon";
  tStart =  new textbox(50,300,50,"Start Time");
  tEnd =  new textbox(300,300,50,"End Time");
  cSave = new button(180,700,60,true,"   Save");
  cSave.setFontSize(30);
 }
 
 void display()
 {
   textSize(30); fill(0);
   text(day,190,50);
   tStart.display();
   tEnd.display();
   if(!tStart.content.matches("[0-9]{4}")){
   
   fill(255,0,0); textSize(20);text(error,160,200);
   }
   else if(Integer.valueOf(tStart.content)>2359)
   {
   fill(255,0,0); textSize(20);text(error,160,200);
   }
   else
   {fill(0); textSize(30); text("Start time: "+tStart.content.substring(0,2)+":"+tStart.content.substring(2,4),130,500);}
  
   if(!tEnd.content.matches("[0-9]{4}")){
   
   fill(255,0,0); textSize(20);text(error,160,200);
   }
   else if(Integer.valueOf(tEnd.content)>2359&&Integer.valueOf(tEnd.content)<Integer.valueOf(tStart.content))
   {
   fill(255,0,0); textSize(20);text(error,160,200);
   }
   else
   {fill(0); textSize(30); text("Start time: "+tEnd.content.substring(0,2)+":"+tStart.content.substring(2,4),130,570);}
   cSave.display();
   if(cSave.on&&!tEnd.content.isEmpty()&&!tStart.content.isEmpty()){page=0; savethis();}
   
 }
 
 void savethis()
 {
  entry.setInt("id", timeID);
  entry.setString("start", tStart.content );
  entry.setString("end", tEnd.content);
  entry.setString("day", day);
  schedule.setJSONObject(timeID,entry);
  saveJSONArray(schedule,"data/schedule.json");
 }
}
