class textbox
{
 int x;
 int y;
 int scale;
 boolean on;
 boolean[] keyPress;
 boolean hover;
 boolean UC;
 String label;
 String content;
 int timer;
 textbox(int x, int y, int scale, String label)
  {
   this.x=x;
   this.y=y;
   this.scale=scale;
   this.label=label;
   timer=0;
   content= "";
   keyPress = new boolean[2];
   keyPress[0]=false;
   keyPress[1]=false;
  }
  
  void display()
  {
    textSize(14);
    update();
    if(on && (mousePressed && hover)||(mousePressed&&!(hover)) )
    {
     on=false;
    }
    if(!on && mousePressed && mouseX>x && mouseX<x+(scale*2) && mouseY>y && mouseY<y+scale)
    {
    on=true;
    }
    if(on)
    {
     String UL="/";
     if(timer>20){UL="";}else{UL="/";}
     if(timer>40){timer=0;}
     fill(255);
     rect(x,y,scale*3,scale,5);
     fill(0);
     text(label+" :"+content+UL,x+(scale/5),y+(scale/2));
     timer++;
     
    }    
    if(!on)
    {
     fill(0);
     rect(x,y,scale*3,scale,5);
     fill(255);
     text(label+" :"+content,x+(scale/5),y+(scale/2));
    }
  }
  
  void update()
  {
   hover = mouseX>x && mouseX<x+(scale*2) && mouseY>y && mouseY<y+scale;
   keyPress[0]=keyPress[1];
   keyPress[1]=keyPressed;
   
   if(on && keyPressed&& !keyPress[0])
   {
     if(Character.isLetterOrDigit(key)||key==' '){content=content+String.valueOf(key);}
     if(key==BACKSPACE&&content.length()!=0){content=content.substring(0,content.length()-1);}
     if(key==ENTER){on=false;}
   }
  }
  
  boolean enter()
  {
      if(on && keyPressed&& !keyPress[0] && keyPressed)
   {
     return true;
   }
   return false;
  }
}

//______________________________________________________________________________________________
class button
{
 int x;
 int y;
 int scale;
 int font;
 boolean on;
 boolean border;
 boolean toggle;
 String label;
 button(int x, int y, int scale, boolean toggle,String label)
 {
   this.x=x;
   this.y=y;
   this.scale=scale;
   this.toggle=toggle;
   this.label=label;
   font=12;
 }
 
 void display()
 {
   textSize(font);
   if(toggle){on=false;}
   if(mouseX>x && mouseX<x+(scale*2) && mouseY>y && mouseY<y+scale)
   {
    textSize(font+1);
   }
   if(mousePressed && mouseX>x && mouseX<x+(scale*2) && mouseY>y && mouseY<y+scale)
   {
    on=true;
   }
   if(border){stroke(0);}else{noStroke();}
   if(on)
   {
    fill(0);
    rect(x,y,scale*2,(scale*1.25),10);
    fill(255);
    text(label,x+(scale/5),y+(scale/2)+4);
   }
   else
   {
    fill(255);
    rect(x,y,scale*2,(scale*1.25),15);
    fill(0);
    text(label,x+(scale/5),y+(scale/2)+5);
   }
 }
 
 void setFontSize(int in)
 {
  font = in;
 }
 
 void setBorder(boolean in)
 {
   border = in;
 }
}
