import java.awt.*;
import java.util.*;
int page = 0;
int timecount;
boolean onWindow;
ArrayList<Leaf> branch;
JSONArray schedule;
JSONObject leafnum;
Boolean studyTime=false;
int clock;
String[] days = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
int day;
button addLeaf;

button[] b;
button p1b;
button leavep2;
button edit;

customTime cust;
void setup()
{
 schedule = loadJSONArray("data/schedule.json");
 leafnum = loadJSONObject("data/leafnumber.json");
 timecount=schedule.size();
 surface.setLocation(750,100);
 size(500,1000);
 clock=0;
 branch = new ArrayList<Leaf>();
 addLeaf = new button (55,50,75, true, "     Add\n     Leaf");
 addLeaf.setFontSize(30);
 Leaf l =  new Leaf(0);
 branch.add(l);
 
 b = new button[7];
 p1b =  new button(180,800,75, true, "     Next\n     Step");
 leavep2 =  new button(195,800,45, true, "    Leave");
 p1b.setFontSize(30);
 leavep2.setFontSize(20);
 leavep2.setBorder(false);
 p1b.setBorder(false);
 edit = new button(285,50,75, true, "       Edit\n      Study");
 edit.setFontSize(25);
 for(int i=0; i<b.length; i++)
 {
  b[i] = new button(190,150+(i*85),60,true,"    Sunday,   Monday,   Tuesday,Wednesday,  Thursday,     Friday, Saturday".split(",")[i]);
  b[i].setFontSize(20);
  b[i].setBorder(false);
 }
 int number_of_leaves=leafnum.getInt("number");
 for(int i=1; i<number_of_leaves; i++)
 {
 Leaf le =  new Leaf(i);
 branch.add(le);
 }
}

void draw()
{
 surface.setLocation(750,100);
 checkIfCurrentlyStudying();
 Point mouse = MouseInfo.getPointerInfo().getLocation();
 onWindow  = mouse.x>750 && mouse.x<750+width && mouse.y>100 && mouse.y<100+height;
 //println(onWindow);
  //println(page);
  background(165,225,190);
  if(page==0)
  {page0();}
  if(page==1)
  {page1();}
  if(page==2)
  {page2();}
  if(studyTime && onWindow)
  {
   clock++;
  }
  if(clock>1000)
  {
   Leaf l =  new Leaf(branch.size());
   branch.add(l);
   clock=0;
  }
}

void page0()
{
  textSize(35); fill(0);
  text("Customize Your Study Schedule",20,70);
  for(int i=0; i<b.length; i++)
 {
  b[i].display();
  if(b[i].on)
  {
   cust = new customTime(days[i],timecount);
   timecount++;
   page=2;
  }
 }
 
 p1b.display();
 if(p1b.on){page=1;}
}

void page1() 
{
  leafnum.setInt("number",branch.size());
  saveJSONObject(leafnum,"data/leafnumber.json");
  strokeWeight(2);  stroke(0); fill(#B98069);
  quad((width/2)-100,900,(width/2)-80,height,(width/2)+80,height,(width/2)+100,900);
  fill(#862600);
  ellipse(width/2,900,200,50);
  edit.display();
  if(edit.on){page=0;}
  if(studyTime && !onWindow)
  {
   fill(255,166,0);
   textSize(30);
   text("Your Plant is Dying!!",145,200);
  }
//++++++++++++++++++++++++++++++++++++++++++++++++
  addLeaf.display();
  textSize(20);
  if(studyTime)
  {
   text("Currently Studying",170,25);
  }else{text("Not Currently Studying",190,25);}
  text("stem length: "+branch.size(),20,height-20);
//++++++++++++++++++++++++++++++++++++++++++++++++
 if(addLeaf.on)
 {
  Leaf l =  new Leaf(branch.size());
  branch.add(l);
 }
 for(int i=0; i<branch.size();i++)
 {
  branch.get(i).display();
  if(branch.get(i).health<1&&i!=0){branch.get(i).dying = true;}
  if(i!=0 && branch.get(i).dead){branch.remove(i);}
 }
}

void page2()
{
 cust.display();
 leavep2.display();
 if(leavep2.on){page=1;}
// println(cust.day);
}

void checkIfCurrentlyStudying()
{
 Calendar cal= Calendar.getInstance();
 int daynum = cal.get(Calendar.DAY_OF_WEEK)-1; // from 1-7
 int m = minute();  /** from 0 - 59*/ String mi = (String.valueOf(m).length()==2)? String.valueOf(m) : "0"+String.valueOf(m);
 int h = hour();    /** from 0 - 23*/ String ho = (String.valueOf(h).length()==2)? String.valueOf(h) : "0"+String.valueOf(h);
 String timestamp = ho+mi;
 int time = Integer.valueOf(timestamp);
// int fulltime = 
 for(int i=0; i<schedule.size(); i++)
 {
  JSONObject range = schedule.getJSONObject(i);

  int start= Integer.valueOf(range.getString("start")) ; 
  int end = Integer.valueOf(range.getString("end")) ; 

//  println(start+" "+timestamp+" "+end);
  if(start<time&&end>time&&days[daynum].equals(range.getString("day")))
  {
   studyTime=true;
  }else studyTime=false;
 }
 //print(studyTime);
}
